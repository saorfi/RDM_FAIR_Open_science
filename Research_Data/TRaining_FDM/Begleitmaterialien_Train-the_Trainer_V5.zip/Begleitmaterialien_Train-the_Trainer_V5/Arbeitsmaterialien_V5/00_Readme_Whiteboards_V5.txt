Generelles:
Für die virtuelle Durchführung wurden mehrere digitale Whiteboards über die Oberfläche Miro angelegt. Es handelt sich hierbei um Vorlagen, die über die zur Verfügung gestellten Links oder einen Import der Back-up-Dateien (im rtb-Format) und einen anzulegenden (zumeist kostenlosen) Miro-Account nachgenutzt werden können. Näherer Erläuterungen zur Nutzung von Miro befinden sich auf den Whiteboards.


Einheit 04

Methode bzw. Schritt: 
Drehen und Wenden: Datenlebenszyklus

Vorlagen-Link des Boards zur Nachnutzung (keine direkte Bearbeitung möglich):
https://miro.com/app/board/uXjVNIL6k1c=/?share_link_id=367634537668

Back-up des Boards als in Miro importierbare Vorlage:
Drehen_und_Wenden_Vorlage.rtb

Hinweise:
Abhängig von der Plenumsgröße werden 2-3 parallele Gruppen und entsprechende Board-Duplikate erstellen vorm Einsatz.

------------

Einheit 09

Methode bzw. Schritt:
Vergleich Speichermedien

Vorlagen-Link des Boards zur Nachnutzung (keine direkte Bearbeitung möglich):
https://miro.com/app/board/uXjVNIK2pSQ=/?share_link_id=252888767377

Back-up des Boards als in Miro importierbare Vorlage:
Speichermedien_Vorlage.rtb

Hinweise:
Ein Board zur Nutzung mit dem gesamten Plenum.

------------

Einheit 12

Methode bzw. Schritt:
Mindmap Formaler Rahmen: Rahmenbedingungen

Vorlagen-Link des Boards zur Nachnutzung (keine direkte Bearbeitung möglich):
https://miro.com/app/board/uXjVNIK2pbE=/?share_link_id=927956044518

Back-up des Boards als in Miro importierbare Vorlage:
Formaler_Rahmen_Rahmenbedingungen_Vorlage.rtb

Hinweise:
Die 3 Boards zum Formalen Rahmen (Rahmenbedingungen, Inhalte und Organisation) werden parallel genutzt, also Aufteilung des Plenums in 3 Gruppen.

------------

Einheit 12

Methode bzw. Schritt:
Mindmap Formaler Rahmen: Inhalte

Vorlagen-Link des Boards zur Nachnutzung (keine direkte Bearbeitung möglich):
https://miro.com/app/board/uXjVNIK2moc=/?share_link_id=850924563113

Back-up des Boards als in Miro importierbare Vorlage:
Formaler_Rahmen_Inhalte_Vorlage.rtb

Hinweise:
Die 3 Boards zum Formalen Rahmen (Rahmenbedingungen, Inhalte und Organisation) werden parallel genutzt, also Aufteilung des Plenums in 3 Gruppen.

------------

Einheit 12

Methode bzw. Schritt:
Mindmap Formaler Rahmen: Organisation

Vorlagen-Link des Boards zur Nachnutzung (keine direkte Bearbeitung möglich):
https://miro.com/app/board/uXjVNIK2my4=/?share_link_id=292455266749

Back-up des Boards als in Miro importierbare Vorlage:
Formaler_Rahmen_Organisation_Vorlage.rtb

Hinweise:
Die 3 Boards zum Formalen Rahmen (Rahmenbedingungen, Inhalte und Organisation) werden parallel genutzt, also Aufteilung des Plenums in 3 Gruppen.

------------

Einheit 21

Methode bzw. Schritt:
Schema X

Vorlagen-Link des Boards zur Nachnutzung (keine direkte Bearbeitung möglich):
https://miro.com/app/board/uXjVNIK2m_M=/?share_link_id=459341292676

Back-up des Boards als in Miro importierbare Vorlage:
Schema_X_Vorlage.rtb

Hinweise:
Abhängig von der Plenumsgröße werden 2-3 parallele Gruppen und entsprechende Board-Duplikate erstellen vorm Einsatz.
